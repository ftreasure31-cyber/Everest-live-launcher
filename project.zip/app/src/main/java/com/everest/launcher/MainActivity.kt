package com.everest.launcher

import android.annotation.SuppressLint
import android.app.role.RoleManager
import android.os.Build
import android.provider.Settings
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        chooser = null
    }

    private val roleReq = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        web.evaluateJavascript("if(window.updDefault)updDefault()", null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                    val u = r?.url ?: return null
                    return loader.shouldInterceptRequest(u)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?
                ): Boolean {
                    if (cb == null || p == null) return false
                    chooser?.onReceiveValue(null)
                    chooser = cb
                    return try { picker.launch(p.createIntent()); true }
                    catch (e: Exception) { chooser = null; false }
                }
            }
        }
        setContentView(web)
        addOnNewIntentListener { _ ->
            web.evaluateJavascript("closeAll();document.getElementById('pager').scrollTo({left:0,behavior:'smooth'})", null)
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { web.evaluateJavascript("goBack()", null) }
        })
    }

    override fun onResume() {
        super.onResume(); web.onResume()
        web.evaluateJavascript("if(window.updDefault)updDefault()", null)
    }
    override fun onPause() { web.onPause(); super.onPause() }

    inner class Bridge {
        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val dock = listOf(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:")),
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
                Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            ).mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            val out = JSONArray()
            for (ri in list) {
                out.put(JSONObject()
                    .put("n", ri.loadLabel(pm).toString())
                    .put("p", ri.activityInfo.packageName)
                    .put("d", dock.contains(ri.activityInfo.packageName))
                    .put("i", b64(ri.loadIcon(pm))))
            }
            return out.toString()
        }

        @JavascriptInterface
        fun isDefault(): Boolean {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val r = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            return r?.activityInfo?.packageName == packageName
        }

        @JavascriptInterface
        fun setDefault() {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        val rm = getSystemService(RoleManager::class.java)
                        if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                            roleReq.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                            return@runOnUiThread
                        }
                    }
                    roleReq.launch(Intent(Settings.ACTION_HOME_SETTINGS))
                } catch (e: Exception) {
                    try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
                }
            }
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            runOnUiThread { packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }
        }
    }

    private fun b64(d: Drawable): String {
        val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 96, 96); d.draw(Canvas(bmp))
        val o = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, o)
        return "data:image/png;base64," + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }
}
